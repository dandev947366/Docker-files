<?php
echo "<h1>hello world this is test</h1>";
phpinfo();
?>